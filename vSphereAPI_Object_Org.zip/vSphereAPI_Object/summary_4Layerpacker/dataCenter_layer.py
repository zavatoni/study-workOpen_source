#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from Tool_Module import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr
from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime

sdkTool = vsphereSDK()


class centerSummary():
    def __init__(self):
        self.summaryDict = dict()
        self.api = sdkCorr()

    def dataStore_base(self):
        dataCenter_seq = list(self.api.content_Data_centerInfo())
        if len(dataCenter_seq) > 0 and len(dataCenter_seq) == 1:
            for store_itm in dataCenter_seq[0].datastore:
                self.summaryDict.update({"{}:{}".format(dataCenter_seq[0].name, store_itm.name): {
                    'name': store_itm.summary.name,
                    'url': store_itm.summary.url,
                    'capacity': store_itm.summary.capacity,
                    'freeSpace': store_itm.summary.freeSpace,
                    'type': store_itm.summary.type,
                    'center overallStatus': dataCenter_seq[0].overallStatus
                }})
        elif len(dataCenter_seq) > 1:
            print("数据中心的相应存储，部分正在升级中")
        return self.summaryDict

    def netWork_base(self):
        dataCenter_seq = list(self.api.content_Data_centerInfo())
        if len(dataCenter_seq) > 0 and len(dataCenter_seq) == 1:
            num = 0
            net_dict = dict()
            for net_itm in dataCenter_seq[0].network:
                net_dict.update({"Net:{}".format(num): net_itm.name})
                num += 1
            self.summaryDict.update({dataCenter_seq[0].name: net_dict})
        elif len(dataCenter_seq) > 1:
            print("数据中心的相应网络，部分正在升级中")
        return self.summaryDict


def Example_main():
    objectCluster = centerSummary()
    objectFrame = DataFrame.from_dict(objectCluster.dataStore_base()).T
    objectHost = DataFrame.from_dict(objectCluster.netWork_base()).T
    with ExcelWriter("dataCenter{}Summary.xlsx".format(strftime("%Y%m%d"))) as object_f:
        objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
        objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
    vsphereSDK().sheetTable_Style(
        ex_str="dataCenter{}Summary.xlsx".format(strftime("%Y%m%d"))
    )


def main():
    objectCluster = centerSummary()
    readConfig = sdkTool.vsphereConfig(configStr='Conf\Account.yml')
    for readKey in readConfig.keys():
        if len(readConfig.get(readKey)) > 0:
            objectFrame = DataFrame.from_dict(objectCluster.dataStore_base()).T
            objectHost = DataFrame.from_dict(objectCluster.netWork_base()).T
            with ExcelWriter(
                    "dataStore/dataCenter{}_Base_{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                     readConfig.get(readKey)['name'])) as object_f:
                objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
                objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
            vsphereSDK().sheetTable_Style(
                ex_str="dataStore/dataCenter{}_Base_{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                     readConfig.get(readKey)['name']))


if __name__ == '__main__':
    main()
