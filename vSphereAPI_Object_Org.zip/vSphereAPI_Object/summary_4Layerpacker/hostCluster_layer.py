#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from Tool_Module import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class hostCLuststatus_Summary():
    def __init__(self):
        self.summaryDict = dict()

    def hostCluster_summary(self):
        hostCluster_seq = list(sdkCorr().content_ClusterInfo())
        for host_itm in hostCluster_seq:
            self.summaryDict.update({host_itm.name: {'totalCpu': host_itm.summary.totalCpu,
                                                     'totalMemory': host_itm.summary.totalMemory,
                                                     'numCpuCores': host_itm.summary.numCpuCores,
                                                     'numCpuThreads': host_itm.summary.numCpuThreads,
                                                     'effectiveCpu': host_itm.summary.effectiveCpu,
                                                     'effectiveMemory': host_itm.summary.effectiveMemory,
                                                     'numHosts': host_itm.summary.numHosts,
                                                     'numEffectiveHosts': host_itm.summary.numEffectiveHosts,
                                                     'overallStatus': host_itm.summary.overallStatus,
                                                     'currentFailoverLevel': host_itm.summary.currentFailoverLevel,
                                                     'totalCpuCapacityMhz': host_itm.summary.usageSummary.totalCpuCapacityMhz,
                                                     'totalMemCapacityMB': host_itm.summary.usageSummary.totalMemCapacityMB,
                                                     'cpuReservationMhz': host_itm.summary.usageSummary.cpuReservationMhz,
                                                     'memReservationMB': host_itm.summary.usageSummary.memReservationMB,
                                                     'poweredOffCpuReservationMhz': host_itm.summary.usageSummary.poweredOffCpuReservationMhz,
                                                     'poweredOffMemReservationMB': host_itm.summary.usageSummary.poweredOffMemReservationMB,
                                                     'cpuDemandMhz': host_itm.summary.usageSummary.cpuDemandMhz,
                                                     'memDemandMB': host_itm.summary.usageSummary.memDemandMB,
                                                     'poweredOffVmCount': host_itm.summary.usageSummary.poweredOffVmCount,
                                                     'totalVmCount': host_itm.summary.usageSummary.totalVmCount,
                                                     'currentEVCModeKey': host_itm.summary.currentEVCModeKey
                                                     }
                                     })
        return self.summaryDict

    def hostCluster_Networksummary(self):
        hostCluster_seq = list(sdkCorr().content_ClusterInfo())
        for host_itm in hostCluster_seq:
            num = 0
            numDict = {}
            for net_itm in host_itm.network:
                numDict.update({"Net:{}".format(num): net_itm.name})
                num += 1
            self.summaryDict.update({host_itm.name: numDict})
        return self.summaryDict


from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime

vsTool = vsphereSDK()


def main():
    objectCluster = hostCLuststatus_Summary()
    readConfig = vsTool.vsphereConfig(configStr='Conf\Account.yml')
    for readKey in readConfig.keys():
        if len(readConfig.get(readKey)) > 0:
            objectFrame = DataFrame.from_dict(objectCluster.hostCluster_summary()).T
            objectHost = DataFrame.from_dict(objectCluster.hostCluster_Networksummary()).T
            with ExcelWriter("dataStore/hostCluster{}Base{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                             readConfig.get(readKey)[
                                                                                 'name'])) as object_f:
                objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
                objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
            vsTool.sheetTable_Style(
                ex_str="dataStore/hostCluster{}Base{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                       readConfig.get(readKey)['name'])
            )


def Example_main():
    objectCluster = hostCLuststatus_Summary()
    objectFrame = DataFrame.from_dict(objectCluster.hostCluster_summary()).T
    objectHost = DataFrame.from_dict(objectCluster.hostCluster_Networksummary()).T
    with ExcelWriter("hostCluster{}Summary.xlsx".format(strftime("%Y%m%d"))) as object_f:
        objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
        objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
    vsphereSystem_class().sheetTable_Style(
        ex_str="hostCluster{}Summary.xlsx".format(strftime("%Y%m%d"))
    )


if __name__ == '__main__':
    main()
