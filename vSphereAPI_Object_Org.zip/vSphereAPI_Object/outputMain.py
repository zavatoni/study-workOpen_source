#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from Tool_Module import vsphereSDK
from corresPond_4layer.indexKey_module import correspond
from triggeredAlarmState__4layerPacker.dataCenter_layer import dataCenterWar_info
from triggeredAlarmState__4layerPacker.vimCluster_layer import vimClusterComputeResource
from triggeredAlarmState__4layerPacker.vimHost_layer import vimHostSystem
from summary_4Layerpacker.dataCenter_layer import centerSummary
from summary_4Layerpacker.hostCluster_layer import hostCLuststatus_Summary
from summary_4Layerpacker.esxi_vimHost_layer import esxiLayer
from summary_4Layerpacker.vmGuest_layer import vmGuestsummary
from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime
from yaml import dump


class outExcel():
    def __init__(self):
        self.setVar = vsphereSDK()

    def correspondStore(self):
        setVar = correspond()
        setVar.clusterTo_esxi()
        setVar.clusterTo_virtHost()
        setVar.esxiTO_virtualHost()
        setVar.dataCenter_to_Cluster_esxi()
        setVar.dataCenter_to_Cluster()
        setVar.dataCenter_to_Cluster_to_esxi_vmGuest()
        setVar.dataCenter_to_vmGuest()

    def warningView(self):
        setObj0 = dataCenterWar_info()
        setObj1 = vimClusterComputeResource()
        setObj2 = vimHostSystem()
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                set_obj0 = DataFrame.from_dict(setObj0.warningInfo()).T
                set_obj1 = DataFrame.from_dict(setObj1.warningInfo()).T
                set_obj2 = DataFrame.from_dict(setObj2.warningInfo()).T
                # 'triggeredAlarmState__4layerPacker/dataStore'
                with ExcelWriter("triggeredAlarmState__4layerPacker/dataStore/vsphere{}warning_{}info.xlsx".format(
                        strftime("%Y%m%d-%H"),
                        readConfig.get(readKey)[
                            'name'])) as object_f:
                    set_obj0.to_excel(object_f, sheet_name="dataCenter warning Info")
                    set_obj1.to_excel(object_f, sheet_name="hostCluster warning Info")
                    set_obj2.to_excel(object_f, sheet_name="vim_hostSystem warning Info")
                self.setVar.sheetTable_Style(
                    ex_str="triggeredAlarmState__4layerPacker/dataStore/vsphere{}warning_{}info.xlsx".format(
                        strftime("%Y%m%d-%H"),
                        readConfig.get(readKey)['name'])
                )

    def warningEx_info(self):
        setObj0 = dataCenterWar_info()
        setObj1 = vimClusterComputeResource()
        setObj2 = vimHostSystem()
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                with open('triggeredAlarmState__4layerPacker/dataStore/center{}_War.yml'.format(
                        readConfig.get(readKey)['name']), 'w') as wf:
                    dump(setObj0.warningSeq(), wf)
                # with open('triggeredAlarmState__4layerPacker/dataStore/hostCluster{}_War.yml'.format(
                #         readConfig.get(readKey)['name']), 'w') as cf:
                #     dump(setObj1.warningSeq(), cf)
                # with open('triggeredAlarmState__4layerPacker/dataStore/esxi{}_War.yml'.format(
                #         readConfig.get(readKey)['name']), 'w') as ef:
                #     dump(setObj2.warningSeq(), ef)

    def dataCenterView(self):
        # 'summary_4Layerpacker/dataStore'
        objectCluster = centerSummary()
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                objectFrame = DataFrame.from_dict(objectCluster.dataStore_base()).T
                objectHost = DataFrame.from_dict(objectCluster.netWork_base()).T
                with ExcelWriter(
                        "summary_4Layerpacker/dataStore/dataCenter{}_Base_{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                                              readConfig.get(readKey)[
                                                                                                  'name'])) as object_f:
                    objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
                    objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
                vsphereSDK().sheetTable_Style(
                    ex_str="summary_4Layerpacker/dataStore/dataCenter{}_Base_{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                                                 readConfig.get(
                                                                                                     readKey)['name']))

    def clusterView(self):
        objectCluster = hostCLuststatus_Summary()
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                objectFrame = DataFrame.from_dict(objectCluster.hostCluster_summary()).T
                objectHost = DataFrame.from_dict(objectCluster.hostCluster_Networksummary()).T
                with ExcelWriter("summary_4Layerpacker/dataStore/hostCluster{}Base{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                                 readConfig.get(readKey)[
                                                                                     'name'])) as object_f:
                    objectFrame.to_excel(object_f, sheet_name="hostCluster Base summary")
                    objectHost.to_excel(object_f, sheet_name="hostCluster Network summary")
                self.setVar.sheetTable_Style(
                    ex_str="summary_4Layerpacker/dataStore/hostCluster{}Base{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                           readConfig.get(readKey)['name'])
                )

    def esxiView(self):
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                esxiFrame = DataFrame.from_dict(esxiLayer().configInfo()).T
                esxiData = DataFrame.from_dict(esxiLayer().hardwareInfo()).T
                esxiExcel = DataFrame.from_dict(esxiLayer().runtimeInfo()).T
                esxiNetwork = DataFrame.from_dict(esxiLayer().networkBase()).T
                esxiWriter = DataFrame.from_dict(esxiLayer().runtime_networkRuntimeInfo_netStackInstanceRuntimeInfo()).T
                esxiPandas = DataFrame.from_dict(esxiLayer().runtime_vsanRuntime_membershipListInfo()).T
                esxiTime = DataFrame.from_dict(esxiLayer().runtime_vsanRuntimeInfo()).T
                esxiStr = DataFrame.from_dict(esxiLayer().runtime_healthSystemRuntime_hardwareStatusInfo()).T
                with ExcelWriter(
                        'summary_4Layerpacker\dataStore\esxiHost{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                                          readConfig.get(readKey)[
                                                                                              'name'])) as strf:
                    esxiData.to_excel(strf, sheet_name='hardware info')
                    esxiFrame.to_excel(strf, sheet_name='config info')
                    esxiExcel.to_excel(strf, sheet_name='runtime info')
                    esxiWriter.to_excel(strf, sheet_name='runtime networkRuntimeinfo netStackInstanceRuntimeInfo')
                    esxiPandas.to_excel(strf, sheet_name='runtime vsanRuntime membershipListInfo')
                    esxiTime.to_excel(strf, sheet_name='runtime vsanRuntimeInfo')
                    esxiStr.to_excel(strf, sheet_name='runtime healthSystemRuntime hardwareStatusInfo')
                    esxiNetwork.to_excel(strf, sheet_name='network Base Info')
                self.setVar.sheetTable_Style(
                    ex_str='summary_4Layerpacker\dataStore\esxiHost{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                                             readConfig.get(readKey)[
                                                                                                 'name'])
                )

    def vimGuestView(self):
        readConfig = self.setVar.vsphereConfig(configStr='Conf\Account.yml')
        for readKey in readConfig.keys():
            if len(readConfig.get(readKey)) > 0:
                vmGuest_runtime = DataFrame.from_dict(vmGuestsummary().runtimeBase()).T
                vmGuest_guest = DataFrame.from_dict(vmGuestsummary().guestBase()).T
                vmGuest_config = DataFrame.from_dict(vmGuestsummary().configBase()).T
                vmGuest_storage = DataFrame.from_dict(vmGuestsummary().storageBase()).T
                vmGuest_quickStats = DataFrame.from_dict(vmGuestsummary().quickStatsBase()).T
                vmGuest_network = DataFrame.from_dict(vmGuestsummary().networkBase()).T
                with ExcelWriter(
                        'summary_4Layerpacker/dataStore/vmGuest{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                                         readConfig.get(readKey)[
                                                                                             'name'])) as gf:
                    vmGuest_config.to_excel(gf, sheet_name='configure BaseInfo')
                    vmGuest_runtime.to_excel(gf, sheet_name='runtime BaseInfo')
                    vmGuest_guest.to_excel(gf, sheet_name='guest BaseInfo')
                    vmGuest_storage.to_excel(gf, sheet_name='storage BaseInfo')
                    vmGuest_quickStats.to_excel(gf, sheet_name='quickStats BaseInfo')
                    vmGuest_network.to_excel(gf, sheet_name='netWork Base Info')
                self.setVar.sheetTable_Style(
                    ex_str='summary_4Layerpacker/dataStore/vmGuest{}Base{}info.xlsx'.format(strftime("%Y%m%d-%H"),
                                                                                            readConfig.get(readKey)[
                                                                                                'name'])
                )


def main():
    outVar = outExcel()
    setVar = vsphereSDK()
    outVar.correspondStore()
    outVar.warningView()
    # outVar.warningEx_info()
    outVar.dataCenterView()
    outVar.clusterView()
    outVar.esxiView()
    outVar.vimGuestView()


if __name__ == '__main__':
    main()
