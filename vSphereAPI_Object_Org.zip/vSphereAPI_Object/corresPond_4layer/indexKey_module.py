#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from Tool_Module import vsphereSDK
from pyVmomi import vim
from corresPond_4layer.indexModule import sdkCorr
from yaml import dump

correspond_summary = dict()

'''
集群---->主机
集群---->主机---->虚拟机
主机---->虚拟机
'''

class correspond(sdkCorr):
    def dataCenter_to_Cluster(self):
        for sdk_itm in self.content_Data_centerInfo():
            sdkNum = 0
            for cluster_itm in sdk_itm.hostFolder.childEntity:
                correspond_summary.update({"{};{}".format(sdk_itm.name, sdkNum): cluster_itm.name})
                sdkNum += 1
        with open('corresPond_4layer/data/dataCenter_to_cluster.yml', 'w') as dcf:
            dump(correspond_summary, dcf)

    def clusterTo_esxi(self):
        for sdk_itm in self.content_ClusterInfo():
            tmp_table = dict()
            for esxi_itm in range(len(list(sdk_itm.host))):
                tmp_table.update({"ESXi:{}".format(esxi_itm): list(sdk_itm.host)[esxi_itm].name})
            correspond_summary[sdk_itm.name] = tmp_table
        with open('corresPond_4layer/data/clusterTOesxi.yml', 'w') as cef:
            dump(correspond_summary, cef)

    def clusterTo_virtHost(self):
        for sdk_itm in self.content_ClusterInfo():
            for host_itm in sdk_itm.host:
                if len(host_itm.vm) > 0:
                    esxi_str = str(host_itm.name).split('.')[0]
                    tmp_iter = dict()
                    for vm_itm in range(len(list(host_itm.vm))):
                        tmp_iter.update({"VM:{}".format(vm_itm): list(host_itm.vm)[vm_itm].name})
                    correspond_summary["{}:{}".format(sdk_itm.name, esxi_str)] = tmp_iter
        with open('corresPond_4layer/data/clusterTo_vm.yml', 'w') as vmf:
            dump(correspond_summary, vmf)

    def esxiTO_virtualHost(self):
        for sdk_itm in self.content_esxiHost():
            itmStr = str(sdk_itm.name).split('.')[0]
            itm_dict = dict()
            for vm_itm in range(len(list(sdk_itm.vm))):
                itm_dict.update({"VM:{}".format(vm_itm): list(sdk_itm.vm)[vm_itm].name})
            correspond_summary[itmStr] = itm_dict
        with open("corresPond_4layer/data/esxi_toVirtHost.yml", 'w') as ef:
            dump(correspond_summary, ef)

    def dataCenter_to_vmGuest(self):
        for sdk_itm in self.content_Data_centerInfo():
            for folder_itm in sdk_itm.vmFolder.childEntity:
                sdk_num = 0
                for vm_itm in folder_itm.childEntity:
                    correspond_summary["{}:{}".format(sdk_itm.name, sdk_num)] = vm_itm.name
                    sdk_num += 1
        with open("corresPond_4layer/data/dataCenter_toVirtHost.yml", 'w') as ef:
            dump(correspond_summary, ef)

    def dataCenter_to_Cluster_esxi(self):
        for sdk_itm in self.content_Data_centerInfo():
            for cluster_itm in sdk_itm.hostFolder.childEntity:
                esxi_clusterKey = "{}:{}".format(sdk_itm.name, cluster_itm.name)
                esxi_num = 0
                clusterEsxi = dict()
                for host_itm in cluster_itm.host:
                    clusterEsxi.update({"ESXi;{}".format(esxi_num): host_itm.name})
                    esxi_num += 1
                correspond_summary[esxi_clusterKey] = clusterEsxi
        with open("corresPond_4layer/data/dataCenter_to_Cluster_esxi.yml", 'w') as ef:
            dump(correspond_summary, ef)

    def dataCenter_to_Cluster_to_esxi_vmGuest(self):
        for sdk_itm in self.content_Data_centerInfo():
            for cluster_itm in sdk_itm.hostFolder.childEntity:
                for host_itm in cluster_itm.host:
                    hostName = str(host_itm.name).split('.')[0]
                    esxi_cluster_vmGuestKey = "{}:{}:{}".format(sdk_itm.name, cluster_itm.name, hostName)
                    if len(host_itm.vm) > 0:
                        vmNum = 0
                        vm_dict = dict()
                        for vm_itm in host_itm.vm:
                            vm_dict.update({"VM-{}".format(vmNum): vm_itm.name})
                            vmNum += 1
                        correspond_summary[esxi_cluster_vmGuestKey] = vm_dict
        with open("corresPond_4layer/data/dataCenter_to_Cluster_to_esxi_vmGuest.yml", 'w') as ef:
            dump(correspond_summary, ef)


def main():
    correspond().clusterTo_esxi()
    correspond().clusterTo_virtHost()
    correspond().esxiTO_virtualHost()
    correspond().dataCenter_to_Cluster_esxi()
    correspond().dataCenter_to_Cluster()
    correspond().dataCenter_to_Cluster_to_esxi_vmGuest()
    correspond().dataCenter_to_vmGuest()

if __name__ == '__main__':
    main()
