#!/usr/bin/python2
# -*- coding:UTF-8 -*-
from Tool_Module import vsphereSDK
from corresPond_4layer.indexModule import sdkCorr


class dataCenterWar_info():
    '''该对象，只获取;vim.Datacenter的监控巡检数据'''

    def __init__(self):
        self.dataCenter_api = sdkCorr()
        self.vsphereTool = vsphereSDK()
        self.center_dict = dict()

    def warningInfo(self):
        for self_itm in self.dataCenter_api.content_Data_centerInfo():
            iterDict = dict()
            iterNum = 0
            for self_iter in self_itm.triggeredAlarmState:
                iterDict.update({'entityName': self_iter.entity.name,
                                 'entity_overallStatus': self_iter.entity.overallStatus,
                                 'overallStatus': self_iter.overallStatus,
                                 'warning time': str(self_iter.time),
                                 'alarmName': self_iter.alarm.info.name,
                                 'alarm systemName': self_iter.alarm.info.systemName,
                                 'alarm Description': self_iter.alarm.info.description,
                                 })
                self.center_dict["{}:WAR{}".format(self_itm.name, iterNum)] = iterDict
                iterNum += 1
        return self.center_dict

    def warningSeq(self):
        entityList = []
        for self_itm in self.dataCenter_api.content_Data_centerInfo():
            for self_iter in self_itm.triggeredAlarmState:
                entityList.append(('entityKey', self_iter.entity), )
        return entityList


from pandas import DataFrame
from pandas import ExcelWriter
from time import strftime

vsTool = vsphereSDK()


def main():
    objectClass = dataCenterWar_info()
    readConfig = vsTool.vsphereConfig(configStr='Conf\Account.yml')
    for readKey in readConfig.keys():
        if len(readConfig.get(readKey)) > 0:
            objectFrame = DataFrame.from_dict(objectClass.warningInfo()).T
            with ExcelWriter("dataStore/dataCenter{}warning_{}info.xlsx".format(strftime("%Y%m%d-%H"),
                                                                      readConfig.get(readKey)['name'])) as object_f:
                objectFrame.to_excel(object_f, sheet_name="dataCenter warning Base Info")
            vsTool.sheetTable_Style(
                ex_str="dataStore/dataCenter{}warning_{}info.xlsx".format(strftime("%Y%m%d-%H"),readConfig.get(readKey)['name'])
            )


if __name__ == '__main__':
    main()
